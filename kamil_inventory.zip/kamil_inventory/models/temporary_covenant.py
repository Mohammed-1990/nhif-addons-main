# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime
from odoo.exceptions import UserError, ValidationError

class TemporaryCovenant(models.Model):

	_name = 'temporary.covenant'
	_inherit = 'need.requisition'

	def issuing_order_on(self):
		sp = self.env['stock.picking'].search([('temporary_covenant_id','=',self.id)])
		if sp:
			self.show_issuing_order = True

	def purchase_request_on(self):
		pr = self.env['purchase.request'].search([('temporary_covenant_id','=',self.id)])
		if pr:
			self.show_purchase_request = True


	document = fields.Binary()
	delever_state = fields.Char(compute='_compute_state')

	line_ids = fields.One2many('temporary.line','requests')

	def action_draft(self):
		if not any(line.line_ids for line in self):
			raise UserError(_('You have to set at least one product from request !'))

		if self.request == 'New':
			seq_code = 'temporary.covenant.seq'
			seq = self.env['ir.sequence'].next_by_code( seq_code )
			if not seq:
				self.env['ir.sequence'].create({
					'name' : seq_code,
					'code' : seq_code,
					'prefix' : ' TC',
					'number_next' : 1,
					'number_increment' : 1,
					'use_date_range' : True,
					'padding' : 4,
					})
			seq = self.env['ir.sequence'].next_by_code( seq_code )
			self.request = seq
		self.write({'state' : 'dept_manager'})
		self.write({'lab_medicine_state' : 'dept_manager'})
		self.write({'medical_supplies_state' : 'dept_manager'})

	# @api.one
	def action_process(self):
		for rec in self:
			po_lines = rec._prepare_po_lines()
			sp_lines = rec._prepare_sp_lines()
			po = rec.env['purchase.request']
			sp = rec.env['stock.picking']

			if sp_lines:
				warehouse = rec.env['stock.warehouse'].search([('company_id', '=', rec.company_id.id)], limit=1)
				picking_type_id = rec.env['stock.picking.type'].search(
					[('code', 'ilike', 'outgoing'), ('for_emloyees_request', '=', True),
					 ('warehouse_id', '=', warehouse.id), ('default_location_src_id', '=', rec.location_id.id)],
					limit=1)

				if not picking_type_id:
					raise ValidationError(
						_('There\'s a problem with the configuration. No picking type is found to handle employees need requests!\n Please contact the system administration.'))

				location_id = rec.location_id

				if not location_id:
					raise ValidationError(
						_('There\'s a problem with the configuration. No stock location is found for this company/branch.\n Please contact the system administration.'))

				location_dest_id = rec.env['stock.location'].search([('usage', '=', 'employees')], limit=1)

				if not location_dest_id:
					raise ValidationError(
						_('There\'s a problem with the configuration. No employees location is defined in the system.\n Please contact the system administration.'))
				sp = sp.create({
					'partner_id': rec.responsible_id.partner_id.id,
					'origin': str(rec.request),
					'scheduled_date': str(datetime.now().date()),
					'state': 'draft',
					'picking_type_id': picking_type_id.id,
					'location_id': location_id.id,
					'location_dest_id': location_dest_id.id,
					'move_ids_without_package': sp_lines,
					'temporary_covenant_id': rec.id})
				sp.action_assign()

			if po_lines:
				po = po.create({
					'company_id': rec.company_id.id,
					'admin_id': rec.department_id.parent_id.id or False,
					'dept_id': rec.department_id.id or False,
					'date': datetime.now().date(),
					'state': 'purchase_department',
					'line_ids': po_lines,
					'temporary_covenant_id': rec.id,
				})

			if sp and not po:
				rec.state = 'available'
			elif po and all(x.reserved_availability == 0 for x in sp.move_ids_without_package):
				rec.state = 'purchase'
			elif po and sp:
				rec.state = 'partially_available'

	def action_view_picking(self):
		sp = self.env['stock.picking'].search([('temporary_covenant_id','=',self.id)])
		if sp:
			return {
			'name':_('Issuing Order'),
			'type':'ir.actions.act_window',
			'res_model':'stock.picking',
			'view_type': 'form',
			'view_mode': 'tree,form',
			# 'view_id':self.env.ref('stock.view_picking_form').id,
			'domain': [('temporary_covenant_id','=',self.id)]
			}
		else:
			raise UserError(_('There\'s no associated issuing order to this need request, please check with Inventory Keeper!!'))

	def action_view_purchase(self):
		pr = self.env['purchase.request'].search([('temporary_covenant_id','=',self.id)])
		if pr:
			return {
			'name':_('Purchase Request'),
			'type':'ir.actions.act_window',
			'res_model':'purchase.request',
			'view_type': 'form',
			'view_mode': 'form',
			'view_id':self.env.ref('kamil_purchase_request.view_purchase_request_form').id,
			'res_id': pr.id
			}
		else:
			raise UserError(_('There\'s no associated purchase request to this need request, please check with purchasing department!!'))


	def _compute_state(self):
		for rec in self:
			need_id = rec.env['stock.picking'].search([('temporary_covenant_id', '=', rec.id)])
			if need_id:
				rec.delever_state = str(need_id.state)
			else:
				rec.delever_state = 'No Delevery Created'




class TemporaryCovenantLine(models.Model):

	_name = 'temporary.line'
	_inherit = 'need.requisition.line'

	return_date = fields.Date(string='Return Date')
	requests = fields.Many2one('temporary.covenant')
